# Authors: Stephen Yoon, Yifan Shi

import numpy as np
import pandas as pd
import optuna
import time
import matplotlib.pyplot as plt
from display_graph import generate_graph
from sklearn.metrics import r2_score, mean_absolute_percentage_error, mean_squared_error
from sklearn.neural_network import MLPRegressor
from sklearn.model_selection import train_test_split
from optuna.pruners import SuccessiveHalvingPruner
from optuna.samplers import TPESampler

def build_mlp(shuffled, train_amt, var_param):
    # Read the input
    df = pd.read_csv('input.csv')
    totalSamples = df.shape[0]
    num_features = df.shape[1]
    all_input = df[['t','p']]
    tlist = df['t'].unique()  # List of time values
    all_conc = df['conc']

    if shuffled:
        # Step 1: Split the dataset into training set
        X_train, X_temp, y_train, y_temp = train_test_split(
            all_input,
            all_conc,
            train_size=train_amt*0.01,
            random_state=42
        )

        # Step 2: Split the remaining data into validation and test sets
        X_val, X_test, y_val, y_test = train_test_split(
            X_temp,
            y_temp,
            test_size=0.9,  # Test set takes 90% of remaining data, validation set takes 10%
            random_state=42
        )
    else:
        # Split training set
        range1 = (all_input['t'] > 0) & (all_input['t'] <= train_amt)
        range2 = (all_input['t'] > tlist[-1] - train_amt) & (all_input['t'] <= tlist[-1])
        X_train = pd.concat([all_input[range1], all_input[range2]])
        y_train = pd.concat(
            [all_conc.iloc[:all_input[range1].shape[0]], all_conc.iloc[-all_input[range2].shape[0]:]])

        # Split remaining data
        X_temp = all_input[(all_input['t'] > train_amt) & (all_input['t'] <= tlist[-1] - train_amt)]
        y_temp = all_conc.iloc[all_input[range1].shape[0]:-all_input[range2].shape[0]]

        # Split validation and test sets from remaining data
        X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.9, random_state=42)

    # Measure time to train the model
    start_time = time.time()

    # Hyperparameter tuning with OPTUNA
    def objective(trial):
        layer_sizes = [trial.suggest_int(f'n_units_layer{i}', 1, 200) for i in range(trial.suggest_int('n_layers', 5, 20))]

        # Suggest L2 regularization parameter
        alpha_l2 = trial.suggest_float('alpha_l2', 1e-6, 1e-3, log=True)
        learning_rate_init = trial.suggest_float('learning_rate', 1e-5, 1e-2, log=True)

        mlp = MLPRegressor(hidden_layer_sizes=layer_sizes, max_iter=1000, random_state=42, alpha=alpha_l2, solver='adam', learning_rate_init=learning_rate_init)
        mlp.fit(X_train, y_train)

        # Compute validation loss for hyperparameter tuning
        y_val_pre = mlp.predict(X_val)
        val_rmse = mean_squared_error(np.array(y_val), np.array(y_val_pre), squared=False)
        val_mape = mean_absolute_percentage_error(np.array(y_val), np.array(y_val_pre))

        # Return validation loss as the optimization objective
        loss = 10*val_rmse + val_mape

        # Manually set an acceptable loss threshold
        max_loss_threshold = 1e-2  # Adjust this value as needed
        if loss <= max_loss_threshold:
            trial.study.stop()  # Manually stop further trials if the desired loss is achieved

        return loss

    # Create a study with a pruner for early stopping
    pruner = SuccessiveHalvingPruner()
    sampler = TPESampler()  # TPE Sampler for Bayesian optimization
    study = optuna.create_study(direction='minimize', pruner=pruner, sampler=sampler)
    study.optimize(objective, n_trials=1000)

    # Select the best parameters
    best_params = study.best_params
    best_params_tuple = []
    layer_size = best_params['n_layers']
    for i in range(layer_size):
        best_params_tuple.append(best_params[f'n_units_layer{i}'])
    best_params_tuple = tuple(best_params_tuple)
    best_alpha_l2 = best_params['alpha_l2']
    best_model = MLPRegressor(best_params_tuple, max_iter=500, random_state=42, alpha=best_alpha_l2, solver='adam')
    best_model.fit(X_train, y_train)

    y_train_pred = best_model.predict(X_train)
    y_val_pred = best_model.predict(X_val)
    y_test_pred = best_model.predict(X_test)

    # Display model performance metrics
    print(f'Time (training only): {time.time() - start_time:.3f} seconds')

    print(f'''Training Set Metrics:
    R^2: {r2_score(y_train, y_train_pred)}
    RMSE: {mean_squared_error(y_train, y_train_pred, squared=False)}
    MAPE: {mean_absolute_percentage_error(y_train, y_train_pred)}''')

    print(f'''Validation Set Metrics:
    R^2: {r2_score(y_val, y_val_pred)}
    RMSE: {mean_squared_error(y_val, y_val_pred, squared=False)}
    MAPE: {mean_absolute_percentage_error(y_val, y_val_pred)}''')

    print(f'''Test Set Metrics:
    R^2: {r2_score(y_test, y_test_pred)}
    RMSE: {mean_squared_error(y_test, y_test_pred, squared=False)}
    MAPE: {mean_absolute_percentage_error(y_test, y_test_pred)}''')

    generate_graph(df, X_train, best_model, var_param)

    # Add y_pred as a new column in X_test
    X_test['conc'] = y_test_pred

    # Write to file with space-separated format
    with open('C:/shiyifan/PythonProject/MLproject/2s_g_pred_shuffled_40.txt', 'w') as f:
        f.write('t p conc\n')  # Write header
        for index, row in X_test.iterrows():
            f.write(f"{row['t']} {row['p']} {row['conc']}\n")  # Write data
